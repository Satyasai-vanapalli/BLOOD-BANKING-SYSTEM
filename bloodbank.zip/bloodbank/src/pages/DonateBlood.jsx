// src/pages/DonateBlood.jsx
import React from 'react';

const DonateBlood = () => (
  <div className="dashboard-container">
    <div className="login-container">
      <h1>Donate Blood</h1>
      <p className="text-center">Fill out the donation form to contribute.</p>
    </div>
  </div>
);

export default DonateBlood;
