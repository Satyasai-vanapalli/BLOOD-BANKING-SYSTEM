// src/pages/RequestBlood.jsx
import React from 'react';

const RequestBlood = () => (
  <div className="dashboard-container">
    <div className="login-container">
      <h1>Request Blood</h1>
      <p className="text-center">Fill out the request form to get help.</p>
    </div>
  </div>
);

export default RequestBlood;
